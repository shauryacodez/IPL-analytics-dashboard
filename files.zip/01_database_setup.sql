-- ============================================================
--  IPL Analytics Dashboard — Database Setup
--  Author  : Shaurya Arora
--  Dataset : Kaggle IPL Matches & Deliveries (2008–2025)
-- ============================================================

CREATE DATABASE IF NOT EXISTS IPL_Analytics;
USE IPL_Analytics;

-- ─────────────────────────────────────────
--  Table 1 : matches
-- ─────────────────────────────────────────
DROP TABLE IF EXISTS matches;

CREATE TABLE matches (
    id              INT            NOT NULL PRIMARY KEY,
    season          VARCHAR(20),
    city            VARCHAR(50),
    date            DATE,
    team1           VARCHAR(100),
    team2           VARCHAR(100),
    toss_winner     VARCHAR(100),
    toss_decision   VARCHAR(10),          -- 'bat' | 'field'
    result          VARCHAR(20),
    dl_applied      TINYINT DEFAULT 0,
    winner          VARCHAR(100),
    win_by_runs     INT  DEFAULT 0,
    win_by_wickets  INT  DEFAULT 0,
    player_of_match VARCHAR(100),
    venue           VARCHAR(200),
    umpire1         VARCHAR(100),
    umpire2         VARCHAR(100)
);

-- ─────────────────────────────────────────
--  Table 2 : deliveries
-- ─────────────────────────────────────────
DROP TABLE IF EXISTS deliveries;

CREATE TABLE deliveries (
    match_id          INT          NOT NULL,
    inning            INT,
    batting_team      VARCHAR(100),
    bowling_team      VARCHAR(100),
    over_no           INT,
    ball              INT,
    batter            VARCHAR(100),
    non_striker       VARCHAR(100),
    bowler            VARCHAR(100),
    is_wide_ball      TINYINT DEFAULT 0,
    is_no_ball        TINYINT DEFAULT 0,
    batsman_runs      INT  DEFAULT 0,
    extra_runs        INT  DEFAULT 0,
    total_runs        INT  DEFAULT 0,
    player_dismissed  VARCHAR(100),
    dismissal_kind    VARCHAR(50),
    fielder           VARCHAR(100),
    FOREIGN KEY (match_id) REFERENCES matches(id)
);

-- ─────────────────────────────────────────
--  Import Instructions (run in MySQL shell)
-- ─────────────────────────────────────────
/*
  LOAD DATA INFILE '/path/to/matches.csv'
  INTO TABLE matches
  FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
  LINES  TERMINATED BY '\n'
  IGNORE 1 ROWS;

  LOAD DATA INFILE '/path/to/deliveries.csv'
  INTO TABLE deliveries
  FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
  LINES  TERMINATED BY '\n'
  IGNORE 1 ROWS;

  Alternative (recommended for Windows):
  Use MySQL Workbench → Table Data Import Wizard
  Select CSV → map columns → import.
*/
