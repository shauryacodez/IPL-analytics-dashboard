-- ============================================================
--  IPL Analytics Dashboard — Analysis Queries
--  Author  : Shaurya Arora
--  Covers  : Player, Team, Venue, Season-level analysis
-- ============================================================

USE IPL_Analytics;

-- ════════════════════════════════════════
--  QUERY 1 — Top Run Scorers (All Time)
-- ════════════════════════════════════════
SELECT
    batter,
    SUM(batsman_runs)                                       AS total_runs,
    COUNT(DISTINCT match_id)                                AS matches_played,
    ROUND(SUM(batsman_runs) / COUNT(DISTINCT match_id), 2) AS avg_runs_per_match,
    SUM(CASE WHEN batsman_runs = 4 THEN 1 ELSE 0 END)      AS fours,
    SUM(CASE WHEN batsman_runs = 6 THEN 1 ELSE 0 END)      AS sixes,
    ROUND(
        SUM(batsman_runs) * 100.0 /
        COUNT(*), 2
    )                                                       AS strike_rate
FROM deliveries
WHERE is_wide_ball = 0
GROUP BY batter
ORDER BY total_runs DESC
LIMIT 20;


-- ════════════════════════════════════════
--  QUERY 2 — Top Wicket Takers (All Time)
-- ════════════════════════════════════════
SELECT
    bowler,
    COUNT(*)                                                AS wickets,
    COUNT(DISTINCT match_id)                                AS matches,
    ROUND(COUNT(*) * 1.0 / COUNT(DISTINCT match_id), 2)    AS wickets_per_match,
    -- Economy rate: runs conceded per over
    ROUND(
        SUM(total_runs) * 6.0 /
        NULLIF(COUNT(*), 0), 2
    )                                                       AS economy_rate
FROM deliveries
WHERE player_dismissed IS NOT NULL
  AND dismissal_kind NOT IN ('run out', 'retired hurt', 'obstructing the field')
GROUP BY bowler
ORDER BY wickets DESC
LIMIT 20;


-- ════════════════════════════════════════
--  QUERY 3 — Most Successful Teams
-- ════════════════════════════════════════
SELECT
    winner,
    COUNT(*)                                AS wins,
    (
        SELECT COUNT(*) FROM matches m2
        WHERE m2.team1 = m.winner OR m2.team2 = m.winner
    )                                       AS matches_played,
    ROUND(
        COUNT(*) * 100.0 /
        NULLIF((
            SELECT COUNT(*) FROM matches m2
            WHERE m2.team1 = m.winner OR m2.team2 = m.winner
        ), 0), 2
    )                                       AS win_percentage
FROM matches m
WHERE winner IS NOT NULL AND winner <> ''
GROUP BY winner
ORDER BY wins DESC;


-- ════════════════════════════════════════
--  QUERY 4 — Highest Scoring Venues
-- ════════════════════════════════════════
SELECT
    m.venue,
    m.city,
    COUNT(DISTINCT d.match_id)                  AS matches_played,
    ROUND(AVG(innings_total.total_score), 1)    AS avg_match_score,
    MAX(innings_total.total_score)              AS highest_match_score
FROM (
    SELECT match_id, SUM(total_runs) AS total_score
    FROM deliveries
    GROUP BY match_id
) AS innings_total
JOIN matches m ON m.id = innings_total.match_id
JOIN deliveries d ON d.match_id = m.id
GROUP BY m.venue, m.city
ORDER BY avg_match_score DESC
LIMIT 15;


-- ════════════════════════════════════════
--  QUERY 5 — Season-wise Run Trends
-- ════════════════════════════════════════
SELECT
    m.season,
    COUNT(DISTINCT m.id)        AS total_matches,
    SUM(d.total_runs)           AS total_runs,
    SUM(CASE WHEN d.batsman_runs = 6 THEN 1 ELSE 0 END) AS total_sixes,
    SUM(CASE WHEN d.batsman_runs = 4 THEN 1 ELSE 0 END) AS total_fours,
    ROUND(SUM(d.total_runs) / COUNT(DISTINCT m.id), 1)  AS avg_runs_per_match
FROM matches m
JOIN deliveries d ON d.match_id = m.id
GROUP BY m.season
ORDER BY m.season;


-- ════════════════════════════════════════
--  QUERY 6 — Toss Decision Impact
-- ════════════════════════════════════════
SELECT
    toss_decision,
    COUNT(*)                                                    AS total_matches,
    SUM(CASE WHEN toss_winner = winner THEN 1 ELSE 0 END)       AS won_after_toss,
    ROUND(
        SUM(CASE WHEN toss_winner = winner THEN 1 ELSE 0 END)
        * 100.0 / COUNT(*), 2
    )                                                           AS win_pct_after_toss
FROM matches
WHERE winner IS NOT NULL
GROUP BY toss_decision;


-- ════════════════════════════════════════
--  QUERY 7 — Chasing vs Defending Success
-- ════════════════════════════════════════
SELECT
    season,
    SUM(CASE WHEN win_by_runs   > 0 THEN 1 ELSE 0 END) AS defended_count,
    SUM(CASE WHEN win_by_wickets > 0 THEN 1 ELSE 0 END) AS chased_count,
    COUNT(*)                                             AS total_matches
FROM matches
WHERE winner IS NOT NULL
GROUP BY season
ORDER BY season;


-- ════════════════════════════════════════
--  QUERY 8 — Player Strike Rate Leaders
--           (min 500 balls faced)
-- ════════════════════════════════════════
SELECT
    batter,
    SUM(batsman_runs)       AS total_runs,
    COUNT(*)                AS balls_faced,
    ROUND(SUM(batsman_runs) * 100.0 / COUNT(*), 2)  AS strike_rate,
    SUM(CASE WHEN batsman_runs = 6 THEN 1 ELSE 0 END) AS sixes
FROM deliveries
WHERE is_wide_ball = 0
GROUP BY batter
HAVING balls_faced >= 500
ORDER BY strike_rate DESC
LIMIT 15;


-- ════════════════════════════════════════
--  QUERY 9 — Orange Cap per Season
-- ════════════════════════════════════════
SELECT season, batter, total_runs
FROM (
    SELECT
        m.season,
        d.batter,
        SUM(d.batsman_runs) AS total_runs,
        RANK() OVER (
            PARTITION BY m.season
            ORDER BY SUM(d.batsman_runs) DESC
        ) AS rnk
    FROM deliveries d
    JOIN matches m ON m.id = d.match_id
    GROUP BY m.season, d.batter
) ranked
WHERE rnk = 1
ORDER BY season;


-- ════════════════════════════════════════
--  QUERY 10 — Purple Cap per Season
-- ════════════════════════════════════════
SELECT season, bowler, wickets
FROM (
    SELECT
        m.season,
        d.bowler,
        COUNT(*) AS wickets,
        RANK() OVER (
            PARTITION BY m.season
            ORDER BY COUNT(*) DESC
        ) AS rnk
    FROM deliveries d
    JOIN matches m ON m.id = d.match_id
    WHERE d.player_dismissed IS NOT NULL
      AND d.dismissal_kind NOT IN ('run out', 'retired hurt')
    GROUP BY m.season, d.bowler
) ranked
WHERE rnk = 1
ORDER BY season;
