# LinkedIn Post — IPL Analytics Dashboard

---

🏏 **Just built an end-to-end IPL Analytics Dashboard covering 17 seasons (2008–2025)!**

Here's the full stack I used:
→ MySQL — designed and queried a 260,000+ row ball-by-ball database  
→ Power BI — built a 4-page interactive dashboard with drill-through  
→ DAX — wrote 20+ custom measures for KPIs and win probability  
→ Excel — data cleaning before ingestion  
→ GitHub — version-controlled the entire project  

**What the dashboard reveals:**
📊 Virat Kohli leads all-time runs with 8,004 across 237 matches  
🎯 DJ Bravo tops all-time wickets with 183 dismissals  
🏟️ Chinnaswamy (Bengaluru) is the highest-scoring ground at 181 avg/innings  
📈 Chasing teams win ~52% of matches in modern IPL  
🏆 Mumbai Indians hold the most titles (5) with CSK having the best win % (60.3%)  

**Key SQL queries I wrote:**
✅ Season-wise run trends using window functions  
✅ Orange & Purple Cap winners per season using RANK() OVER (PARTITION BY)  
✅ Venue scoring analysis with nested subqueries  
✅ Toss decision impact analysis  

📂 Full project on GitHub: [link]  
📊 Dashboard live on Power BI Service: [link]  

#PowerBI #SQL #DataAnalytics #IPL #Cricket #BCA #FresherJobs #DataVisualization #DAX #MySQL #BusinessAnalyst
