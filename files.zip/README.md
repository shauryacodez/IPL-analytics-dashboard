# 🏏 IPL Analytics Dashboard
### Team, Player & Venue Performance Analysis (2008–2025)

![Power BI](https://img.shields.io/badge/Power%20BI-F2C811?style=for-the-badge&logo=powerbi&logoColor=black)
![MySQL](https://img.shields.io/badge/MySQL-4479A1?style=for-the-badge&logo=mysql&logoColor=white)
![Excel](https://img.shields.io/badge/Excel-217346?style=for-the-badge&logo=microsoft-excel&logoColor=white)
![DAX](https://img.shields.io/badge/DAX-F2C811?style=for-the-badge&logo=powerbi&logoColor=black)
![GitHub](https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github)

---

## 📌 Problem Statement

The Indian Premier League generates massive volumes of match data across 17+ seasons. Coaches, analysts, and cricket fans often lack a consolidated view of how players, teams, and venues have performed over time. This project builds a **4-page interactive Power BI dashboard** backed by a **MySQL database** to answer questions like:

- Who are the all-time top run-scorers and wicket-takers?
- Which team wins most consistently after winning the toss?
- Which grounds favour batters vs. bowlers?
- How has scoring evolved across IPL seasons?

---

## 📂 Dataset

| File | Source | Rows (approx.) | Key Columns |
|---|---|---|---|
| `matches.csv` | Kaggle — IPL Complete Dataset | ~1,100 | id, season, city, date, team1, team2, winner, venue, toss_decision |
| `deliveries.csv` | Kaggle — IPL Complete Dataset | ~260,000 | match_id, batter, bowler, batsman_runs, total_runs, player_dismissed |

**Download links:**
- [IPL Matches Dataset (Kaggle)](https://www.kaggle.com/datasets/patrickb1912/ipl-complete-dataset-20082020)
- [IPL Ball-by-Ball Dataset (Kaggle)](https://www.kaggle.com/datasets/patrickb1912/ipl-complete-dataset-20082020)

Place both CSV files inside the `/Dataset` folder before running SQL scripts.

---

## 🗃️ SQL Analysis

### Database
```sql
CREATE DATABASE IPL_Analytics;
USE IPL_Analytics;
```

### Tables Created
- **`matches`** — one row per match (17 columns incl. venue, toss, winner, margins)
- **`deliveries`** — one row per ball bowled (17 columns incl. runs, dismissal type)

### Queries Written (`SQL-Queries/02_analysis_queries.sql`)

| # | Query | Purpose |
|---|---|---|
| 1 | Top Run Scorers | All-time batting leaderboard with SR and boundary count |
| 2 | Top Wicket Takers | All-time bowling leaderboard with economy rate |
| 3 | Most Successful Teams | Win count + win percentage per team |
| 4 | Highest Scoring Venues | Average & peak match scores by ground |
| 5 | Season-wise Run Trends | How scoring has changed across 2008–2025 |
| 6 | Toss Decision Impact | Does winning the toss help win the match? |
| 7 | Chasing vs Defending | Which strategy wins more? Per season breakdown |
| 8 | Strike Rate Leaders | Min 500 balls — who scores fastest? |
| 9 | Orange Cap per Season | Highest run-scorer in each edition |
| 10 | Purple Cap per Season | Highest wicket-taker in each edition |

---

## 📊 Dashboard Insights

### Page 1 — Executive Overview
- **KPI Cards**: Total Matches · Total Runs · Total Sixes · Total Fours · Total Wickets
- **Line Chart**: Runs scored per season (2008–2025) — scoring has risen ~20% since 2008
- **Bar Chart**: Matches played per season
- **Donut Chart**: Toss decision breakdown (bat first vs. field first)
- **Insight**: Teams choosing to field first after winning the toss win ~52% of matches

### Page 2 — Team Analysis
- **Bar Chart**: All-time win count by franchise
- **Donut Chart**: Win percentage by team
- **Slicer**: Filter by team (MI, CSK, RCB, KKR, DC, SRH, PBKS, RR, GT, LSG)
- **Insight**: Mumbai Indians lead with the most titles; CSK has the best win percentage among 10+ season teams

### Page 3 — Player Analysis
- **Table**: Orange Cap leaderboard (top run scorers per season)
- **Table**: Purple Cap leaderboard (top wicket takers per season)
- **Bar Chart**: All-time top 10 run scorers
- **Bar Chart**: All-time top 10 wicket takers
- **Scatter**: Strike Rate vs. Total Runs (bubble = sixes hit)
- **Insight**: Virat Kohli holds the all-time record for most IPL runs

### Page 4 — Venue Analysis
- **Bar Chart**: Top 10 highest-scoring grounds (avg match total)
- **Column Chart**: Average first innings score by venue
- **KPI**: Chasing success rate overall (~52%)
- **Map Visual**: Ground locations across India
- **Insight**: Chinnaswamy (Bangalore) consistently produces the highest average scores

---

## 🔧 Tools Used

| Tool | Purpose |
|---|---|
| **MySQL 8.0** | Database creation, data ingestion via LOAD DATA INFILE, all 10 analytical queries |
| **Power BI Desktop** | 4-page interactive dashboard, slicers, drill-through |
| **DAX** | 20+ custom measures for KPIs, percentages, conditional aggregations |
| **Excel** | Initial data cleaning (nulls, date formatting, team name standardisation) |
| **GitHub** | Version control, README documentation |

---

## 🗂️ Project Structure

```
IPL-Analytics-Dashboard/
│
├── Dataset/
│   ├── matches.csv              ← Download from Kaggle
│   └── deliveries.csv           ← Download from Kaggle
│
├── SQL-Queries/
│   ├── 01_database_setup.sql    ← CREATE DATABASE, tables, import instructions
│   └── 02_analysis_queries.sql  ← All 10 analytical queries
│
├── PowerBI-File/
│   ├── IPL_Dashboard.pbix       ← Main Power BI file (open in Power BI Desktop)
│   └── DAX_Measures.txt         ← All DAX measure definitions
│
├── Dashboard-Screenshots/
│   ├── page1_overview.png
│   ├── page2_teams.png
│   ├── page3_players.png
│   └── page4_venues.png
│
└── README.md
```

---

## 🚀 How to Run This Project

1. **Clone the repository**
   ```bash
   git clone https://github.com/YOUR_USERNAME/IPL-Analytics-Dashboard.git
   cd IPL-Analytics-Dashboard
   ```

2. **Download the datasets** from Kaggle and place in `/Dataset`

3. **Set up the database**
   ```bash
   mysql -u root -p < SQL-Queries/01_database_setup.sql
   ```
   Then import CSVs via MySQL Workbench Table Data Import Wizard

4. **Run analysis queries**
   ```bash
   mysql -u root -p IPL_Analytics < SQL-Queries/02_analysis_queries.sql
   ```

5. **Open Power BI**
   - Open `PowerBI-File/IPL_Dashboard.pbix`
   - Update the MySQL connection string to your local server
   - Refresh data → all visuals will populate

---

## 🔮 Future Improvements

- [ ] Add 2025 season data as it completes
- [ ] Integrate live data via Cricbuzz/ESPNcricinfo API
- [ ] Build a **predictive win probability model** using Python (scikit-learn)
- [ ] Add a **player auction value estimator** using performance metrics
- [ ] Deploy dashboard to Power BI Service for public sharing
- [ ] Add fielding stats when dataset support improves
- [ ] Player comparison tool (head-to-head batting/bowling)

---

## 👨‍💻 Author

**Shaurya Arora**  
BCA Graduate | Aspiring Business Analyst / IT Consultant  
📍 Delhi/NCR, India  

[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-blue?style=flat&logo=linkedin)](https://linkedin.com/in/YOUR_PROFILE)
[![GitHub](https://img.shields.io/badge/GitHub-Follow-black?style=flat&logo=github)](https://github.com/YOUR_USERNAME)

---

## 📄 License

This project is for educational and portfolio purposes. Dataset credits to Kaggle contributors. IPL is a registered trademark of BCCI.
